let Numero1 = document.querySelector("#Numero1");
let Numero2 = document.querySelector("#Numero2");
let btSomar = document.querySelector("#btSomar");
let resultado = document.querySelector("#resultado");

function somarnumeros() {
    // Get the input values as integers
    const num1 = parseInt(Numero1.value);
    const num2 = parseInt(Numero2.value);

    // Check if either number is not valid
    if (isNaN(num1) || isNaN(num2)) {
        resultado.innerHTML = "<p>Por favor, insira dois números inteiros válidos.</p>";
        return;
    }

    // Perform the calculations
    const soma = num1 + num2;
    const subtracao = num1 - num2;
    const multiplicacao = num1 * num2;
    const divisao = num2 !== 0 ? (num1 / num2).toFixed(2) : "Indefinida (divisão por zero)";

    // Display the results
    resultado.innerHTML = `
        <p>soma: ${soma}</p>
        <p>subtracao: ${subtracao}</p>
        <p>multiplicacao: ${multiplicacao}</p>
        <p>divisao: ${divisao}</p>
    `;
}

// Attach the function to the button's click event
btSomar.onclick = function () {
    somarnumeros();
};