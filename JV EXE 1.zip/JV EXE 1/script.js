let cotacao = document.querySelector ("#cotacao");
let resultado = document.querySelector ("#resultado");
let btSomar = document.querySelector ("#btSomar");


function somarnumeros() {
    const cotacao = parseFloat(document.getElementById('cotacao').value);
    if (isNaN(cotacao) || cotacao <= 0) {
        alert('Por favor, insira um valor válido para a cotação.');
        return;
    }

    const aumentos = [1, 2, 5, 10];
    let resultadoHTML = '<h2>Valores com aumento:</h2>';

    aumentos.forEach(aumento => {
        const valorComAumento = cotacao * (1 + aumento / 100);
        resultadoHTML += `<p><strong>${aumento}%</strong>: R$ ${valorComAumento.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</p>`;
    });

    document.getElementById('resultado').innerHTML = resultadoHTML;

}

btSomar.onclick = function () {
    somarnumeros();
}
