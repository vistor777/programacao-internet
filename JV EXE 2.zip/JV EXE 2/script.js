let cotacao = document.querySelector ("#cotacao");
let resultado = document.querySelector ("#resultado");
let resultado2 = document.querySelector ("#resultado2");
let btSomar = document.querySelector ("#btSomar");



function somarnumeros() {
    // Pega o valor do input
    const valor = document.getElementById('cotacao').value;

    // Converte o valor para número (porque vem como string)
    const numero = parseFloat(valor);

    // Verifica se é um número válido
    if (!isNaN(numero)) {
        const ovos = numero * 2;   // Exemplo de conta para ovos
        const queijo = numero * 50; // Exemplo de conta para queijo

        document.getElementById('resultado').textContent = "Ovos: " + ovos;
        document.getElementById('resultado2').textContent = "Queijo: " + queijo + "g";
    } else {
        document.getElementById('resultado').textContent = "Por favor, insira um número válido.";
        document.getElementById('resultado2').textContent = "";
    }
}

btSomar.onclick = function () {
    somarnumeros();
}